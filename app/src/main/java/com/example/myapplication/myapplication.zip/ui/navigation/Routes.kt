package com.example.myapplication.ui.navigation

object Routes {
    const val ADD_CATEGORY = "add_category"
}
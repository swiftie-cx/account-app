package com.example.myapplication.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search // 导入搜索图标
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

/**
 * 搜索页面 (极简版)
 * 仅包含 UI 框架，无 ViewModel 逻辑
 * (修改版：按照 10-07-17.png 添加“常用”和“筛选”)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    navController: NavHostController,
) {
    // 1. 状态：使用 remember，而不是 ViewModel
    var searchText by remember { mutableStateOf("") }
    var selectedFilterIndex by remember { mutableStateOf(0) }
    val filters = listOf("全部", "支出", "收入", "转账")

    val focusRequester = remember { FocusRequester() }

    // 页面打开时，自动激活搜索框
    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Scaffold(
        topBar = {
            // 顶部应用栏
            TopAppBar(
                title = { Text("搜索") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding) // 应用 Scaffold 的 padding
                .padding(horizontal = 16.dp) // 为内容区添加左右 padding
        ) {

            // 2. 搜索框
            OutlinedTextField(
                value = searchText,
                onValueChange = { searchText = it },
                placeholder = { Text("搜索备注、分类") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "搜索") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .focusRequester(focusRequester),
                singleLine = true
            )

            // 3. 按钮：类型过滤器
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                filters.forEachIndexed { index, title ->
                    FilterChip(
                        selected = selectedFilterIndex == index,
                        onClick = { selectedFilterIndex = index },
                        label = { Text(title) }
                    )
                }
            }

            // 分割线
            Divider(modifier = Modifier.padding(vertical = 8.dp))

            // 4. (新) 常用 按钮
            SearchFilterSection(
                title = "常用",
                chipLabels = listOf("本月", "上月", "近7天")
            )

            // 5. (新) 筛选 按钮
            SearchFilterSection(
                title = "筛选",
                chipLabels = listOf("全部")
            )

            // 6. 页面内容：暂时为空
            Spacer(modifier = Modifier.fillMaxSize())
        }
    }
}

/**
 * (新) 搜索页筛选器小节 Composable
 * (用于 "常用" 和 "筛选" 部分)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchFilterSection(
    title: String,
    chipLabels: List<String>
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp) // 小节的上下间距
    ) {
        // 标题 (例如 "常用")
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        // 按钮行
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp) // 按钮间距
        ) {
            chipLabels.forEach { label ->
                // AssistChip 适合用于这种建议性操作
                AssistChip(
                    onClick = { /* 暂时不做任何事 */ },
                    label = { Text(label) }
                )
            }
        }
    }
}
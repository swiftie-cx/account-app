package com.example.myapplication.ui.screen

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.myapplication.ui.viewmodel.ExpenseViewModel
import kotlin.math.abs
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.pagerTabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale


enum class ChartMode { WEEK, MONTH, YEAR }
enum class TransactionType { INCOME, EXPENSE }

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChartScreen(viewModel: ExpenseViewModel) {
    val allTransactions by viewModel.allExpenses.collectAsState(initial = emptyList())

    var transactionType by remember { mutableStateOf(TransactionType.EXPENSE) }
    var chartMode by remember { mutableStateOf(ChartMode.MONTH) }
    var showTypePicker by remember { mutableStateOf(false) }

    val filteredTransactions = remember(allTransactions, transactionType) {
        allTransactions.filter {
            if (transactionType == TransactionType.INCOME) it.amount > 0 else it.amount < 0
        }
    }

    val groupedData = remember(filteredTransactions, chartMode) {
        when (chartMode) {
            ChartMode.WEEK -> filteredTransactions.groupBy { getWeekOfYear(it.date.time) }
            ChartMode.MONTH -> filteredTransactions.groupBy { getMonthOfYear(it.date.time) }
            ChartMode.YEAR -> filteredTransactions.groupBy { getYear(it.date.time) }
        }
    }

    val sortedGroupKeys = remember(groupedData) {
        groupedData.keys.sortedDescending()
    }

    val pagerState = rememberPagerState(pageCount = { sortedGroupKeys.size })
    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            FilterBar(
                transactionType = transactionType,
                chartMode = chartMode,
                showTypePicker = showTypePicker,
                onTypeChange = { transactionType = it },
                onChartModeChange = { chartMode = it },
                onShowTypePicker = { showTypePicker = it },
                pagerState = pagerState,
                sortedGroupKeys = sortedGroupKeys,
                onTabClick = { index ->
                    coroutineScope.launch {
                        pagerState.animateScrollToPage(index)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            if (sortedGroupKeys.isNotEmpty()) {
                HorizontalPager(state = pagerState) {
                    val key = sortedGroupKeys[it]
                    val data = groupedData[key] ?: emptyList()
                    ChartPage(data = data)
                }
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("没有记录")
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun FilterBar(
    transactionType: TransactionType,
    chartMode: ChartMode,
    showTypePicker: Boolean,
    onTypeChange: (TransactionType) -> Unit,
    onChartModeChange: (ChartMode) -> Unit,
    onShowTypePicker: (Boolean) -> Unit,
    pagerState: androidx.compose.foundation.pager.PagerState,
    sortedGroupKeys: List<String>,
    onTabClick: (Int) -> Unit
) {
    Column(modifier = Modifier.background(MaterialTheme.colorScheme.primaryContainer)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { onShowTypePicker(true) }) {
                    Text(if (transactionType == TransactionType.INCOME) "收入" else "支出", style = MaterialTheme.typography.titleLarge)
                    Icon(Icons.Default.ArrowDropDown, contentDescription = "选择类型")
                }
                DropdownMenu(expanded = showTypePicker, onDismissRequest = { onShowTypePicker(false) }) {
                    DropdownMenuItem(text = { Text("收入") }, onClick = { onTypeChange(TransactionType.INCOME); onShowTypePicker(false) })
                    DropdownMenuItem(text = { Text("支出") }, onClick = { onTypeChange(TransactionType.EXPENSE); onShowTypePicker(false) })
                }
            }
            IconButton(onClick = { /* TODO: Implement date picker */ }) {
                Icon(Icons.Default.DateRange, contentDescription = "选择日期")
            }
        }
        TabRow(
            selectedTabIndex = chartMode.ordinal,
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
            indicator = {}
        ) {
            val modes = listOf("周", "月", "年")
            modes.forEachIndexed { index, title ->
                val selected = chartMode.ordinal == index
                Tab(
                    selected = selected,
                    onClick = { onChartModeChange(ChartMode.values()[index]) },
                    modifier = Modifier
                        .padding(horizontal = 4.dp, vertical = 8.dp)
                        .clip(RoundedCornerShape(50))
                ) {
                    Text(text = title, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
        if (sortedGroupKeys.isNotEmpty()) {
            ScrollableTabRow(
                selectedTabIndex = pagerState.currentPage,
                containerColor = Color.Transparent,
                edgePadding = 0.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.Indicator(
                        modifier = Modifier.pagerTabIndicatorOffset(pagerState, tabPositions)
                    )
                }
            ) {
                sortedGroupKeys.forEachIndexed { index, key ->
                    Tab(
                        selected = pagerState.currentPage == index,
                        onClick = { onTabClick(index) },
                        text = {
                            when (chartMode) {
                                ChartMode.WEEK -> {
                                    val (year, week) = key.split("-W")
                                    val (start, end) = getWeekDateRange(year.toInt(), week.toInt())
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(text = "${week}周")
                                        Text(text = "$start - $end", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                                ChartMode.MONTH -> Text(key.replace("-", "年") + "月")
                                ChartMode.YEAR -> Text(key + "年")
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ChartPage(data: List<com.example.myapplication.data.Expense>) {
    val categorySums = remember(data) {
        data.groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { abs(it.amount) } }
            .toList().sortedByDescending { it.second }
    }
    val totalAmount = remember(categorySums) {
        categorySums.sumOf { it.second }
    }
    val colors = remember { getChartColors() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp) // Apply padding to the content
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                if (totalAmount > 0) {
                    Canvas(modifier = Modifier.size(200.dp)) {
                        var startAngle = -90f
                        categorySums.forEachIndexed { index, (_, sum) ->
                            val sweepAngle = (sum / totalAmount * 360).toFloat()
                            val color = colors[index % colors.size]
                            drawArc(
                                color = color,
                                startAngle = startAngle,
                                sweepAngle = sweepAngle,
                                useCenter = false,
                                style = Stroke(width = 50f, cap = StrokeCap.Round)
                            )
                            startAngle += sweepAngle
                        }
                    }
                    Text(text = "¥${String.format("%.2f", totalAmount)}", style = MaterialTheme.typography.headlineMedium)
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("这段时间没有记录")
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
        itemsIndexed(categorySums) { index, (category, sum) ->
            val percentage = if (totalAmount > 0) (sum / totalAmount * 100) else 0.0
            LegendItem(
                color = colors[index % colors.size],
                category = category,
                amount = sum,
                percentage = percentage
            )
        }
    }
}


@Composable
fun LegendItem(color: Color, category: String, amount: Double, percentage: Double) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.size(16.dp).background(color))
        Text(text = category, modifier = Modifier.weight(1f).padding(start = 8.dp))
        Text(text = "${String.format("%.2f", percentage)}%", modifier = Modifier.padding(start = 8.dp))
        Text(text = "¥${String.format("%.2f", amount)}", modifier = Modifier.padding(start = 8.dp))
    }
}

private fun getWeekOfYear(time: Long): String {
    val calendar = java.util.Calendar.getInstance().apply { timeInMillis = time }
    return "${calendar.get(java.util.Calendar.YEAR)}-W${calendar.get(java.util.Calendar.WEEK_OF_YEAR)}"
}

private fun getMonthOfYear(time: Long): String {
    val calendar = java.util.Calendar.getInstance().apply { timeInMillis = time }
    return "${calendar.get(java.util.Calendar.YEAR)}-${calendar.get(java.util.Calendar.MONTH) + 1}"
}

private fun getYear(time: Long): String {
    val calendar = java.util.Calendar.getInstance().apply { timeInMillis = time }
    return "${calendar.get(java.util.Calendar.YEAR)}"
}

private fun getWeekDateRange(year: Int, weekOfYear: Int): Pair<String, String> {
    val calendar = java.util.Calendar.getInstance().apply {
        clear()
        set(java.util.Calendar.YEAR, year)
        set(java.util.Calendar.WEEK_OF_YEAR, weekOfYear)
    }
    val format = SimpleDateFormat("MM月dd日", Locale.getDefault())
    val start = format.format(calendar.time)
    calendar.add(java.util.Calendar.DAY_OF_WEEK, 6)
    val end = format.format(calendar.time)
    return Pair(start, end)
}

private fun getChartColors(): List<Color> {
    return listOf(
        Color(0xFFF44336), Color(0xFFE91E63), Color(0xFF9C27B0), Color(0xFF673AB7),
        Color(0xFF3F51B5), Color(0xFF2196F3), Color(0xFF03A9F4), Color(0xFF00BCD4),
        Color(0xFF009688), Color(0xFF4CAF50), Color(0xFF8BC34A), Color(0xFFCDDC39)
    )
}

package com.swiftiecx.timeledger.data.model

/**
 * 收入/支出类型（供 data 层、ui 层共同使用）
 */
enum class CategoryType {
    INCOME,
    EXPENSE
}

package com.swiftiecx.timeledger.data.model

enum class CategoryType { EXPENSE, INCOME }

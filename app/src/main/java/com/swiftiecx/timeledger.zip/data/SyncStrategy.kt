package com.swiftiecx.timeledger.data

// 兼容旧代码：SyncScreen / ExpenseViewModel 仍然 import com.swiftiecx.timeledger.data.SyncStrategy
typealias SyncStrategy = com.swiftiecx.timeledger.data.repository.SyncStrategy

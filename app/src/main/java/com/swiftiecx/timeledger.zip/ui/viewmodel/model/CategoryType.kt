package com.swiftiecx.timeledger.ui.viewmodel.model

enum class CategoryType { EXPENSE, INCOME }

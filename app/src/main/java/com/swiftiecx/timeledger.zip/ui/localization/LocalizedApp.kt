package com.swiftiecx.timeledger.ui.localization

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import java.util.Locale

fun createLocalizedContext(base: Context, languageTag: String): Context {
    val tag = languageTag.trim()
    if (tag.isEmpty()) return base // 跟随系统

    val locale = Locale.forLanguageTag(tag)
    val config = Configuration(base.resources.configuration).apply {
        setLocales(LocaleList(locale))
    }
    return base.createConfigurationContext(config)
}

@Composable
fun LocalizedApp(languageTag: String, content: @Composable () -> Unit) {
    val base = LocalContext.current
    val localized = remember(base, languageTag) { createLocalizedContext(base, languageTag) }
    CompositionLocalProvider(LocalContext provides localized) {
        content()
    }
}

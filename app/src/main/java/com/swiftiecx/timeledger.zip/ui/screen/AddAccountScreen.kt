package com.swiftiecx.timeledger.ui.screen

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.swiftiecx.timeledger.R
import com.swiftiecx.timeledger.data.Account
import com.swiftiecx.timeledger.ui.navigation.AccountTypeManager
import com.swiftiecx.timeledger.ui.navigation.IconMapper
import com.swiftiecx.timeledger.ui.viewmodel.ExpenseViewModel
import java.util.Locale
import kotlin.math.max

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAccountScreen(
    navController: NavHostController,
    viewModel: ExpenseViewModel,
    accountId: Long? = null,
    presetCategory: String = "FUNDS",
    presetDebtType: String? = null
) {
    val allAccounts by viewModel.allAccounts.collectAsState(initial = emptyList())

    // 类型列表 (Key, ResId)
    val accountTypes = remember { AccountTypeManager.getAllTypes() }

    // --- 基础输入状态 ---
    var accountName by remember { mutableStateOf("") }

    // FUNDS：余额；CREDIT：欠款；DEBT：未结清金额
    var amountInput by remember { mutableStateOf("") }

    // CREDIT 专用：额度
    var creditLimitInput by remember { mutableStateOf("") }

    // ✅ 类别 / 债务方向：新建时用路由 preset；编辑时会被数据库覆盖
    var category by remember { mutableStateOf(presetCategory) }

    // ✅ 如果是 DEBT 且没传 debtType，默认 PAYABLE（借入/应付）
    var debtType by remember {
        mutableStateOf(
            when (presetCategory) {
                "DEBT" -> presetDebtType ?: "PAYABLE"
                else -> presetDebtType
            }
        )
    }

    // FUNDS/CREDIT 用的“账户类型”
    var selectedTypeKey by remember { mutableStateOf(accountTypes.first().first) }

    val currencies = listOf(
        "CNY", "USD", "EUR", "JPY", "HKD", "GBP", "AUD", "CAD",
        "SGD", "TWD", "KRW"
    )
    var selectedCurrency by remember { mutableStateOf(currencies.first()) }

    val icons = remember {
        listOf(
            "Wallet", "Bank", "CreditCard", "TrendingUp",
            "Smartphone", "AttachMoney", "Savings", "Payment",
            "CurrencyExchange", "Euro", "ShowChart", "PieChart"
        ).map { it to IconMapper.getIcon(it) }
    }
    var selectedIcon by remember { mutableStateOf(icons.first().first) }

    var isDataLoaded by remember { mutableStateOf(false) }

    // --- 编辑回填：以数据库为准（忽略 preset） ---
    LaunchedEffect(accountId, allAccounts) {
        if (accountId != null && !isDataLoaded && allAccounts.isNotEmpty()) {
            val acc = allAccounts.find { it.id == accountId } ?: return@LaunchedEffect

            accountName = acc.name
            selectedCurrency = acc.currency
            selectedIcon = acc.iconName

            category = acc.category
            debtType = when (acc.category) {
                "DEBT" -> acc.debtType ?: "PAYABLE"
                else -> acc.debtType
            }

            // FUNDS/CREDIT：保留原 type 的兼容映射
            selectedTypeKey = AccountTypeManager.getStableKey(acc.type)

            when (acc.category) {
                "CREDIT" -> {
                    // 欠款（正数显示）
                    val debt = max(acc.initialBalance, 0.0)
                    amountInput = formatNumberForInput(debt)

                    // 额度
                    val limit = max((acc.creditLimit ?: 0.0), 0.0)
                    creditLimitInput = formatNumberForInput(limit)
                }
                "DEBT" -> {
                    // 未结清金额：永远用正数显示
                    amountInput = formatNumberForInput(max(acc.initialBalance, 0.0))
                }
                else -> {
                    // FUNDS：余额
                    amountInput = formatNumberForInput(acc.initialBalance)
                }
            }

            isDataLoaded = true
        }
    }

    // --- UI 颜色 ---
    val primaryColor = MaterialTheme.colorScheme.primary
    val surfaceColor = MaterialTheme.colorScheme.surface
    val bgColor = MaterialTheme.colorScheme.surfaceContainerLow

    // 预览用显示
    val previewLabel = when (category) {
        "CREDIT" -> "欠款"
        "DEBT" -> "未结清金额"
        else -> "余额"
    }

    Scaffold(
        containerColor = bgColor,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        stringResource(if (accountId == null) R.string.add_account_title else R.string.edit_account_title),
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            val name = accountName.trim()
                            if (name.isBlank()) return@IconButton

                            val amountVal = amountInput.toDoubleOrNull() ?: 0.0
                            val limitVal = creditLimitInput.toDoubleOrNull() ?: 0.0

                            // 旧字段兼容：只有 CREDIT 认为是 liability
                            val isLiability = category == "CREDIT"

                            val finalType = when (category) {
                                "DEBT" -> "debt"
                                else -> selectedTypeKey
                            }

                            val finalInitialBalance = when (category) {
                                // CREDIT：initialBalance 存欠款（正数）
                                "CREDIT" -> max(amountVal, 0.0)
                                // DEBT：initialBalance 存未结清金额（正数）
                                "DEBT" -> max(amountVal, 0.0)
                                // FUNDS：按输入
                                else -> amountVal
                            }

                            val finalDebtType = if (category == "DEBT") {
                                (debtType ?: "PAYABLE")
                            } else {
                                null
                            }

                            val toSave = Account(
                                id = accountId ?: 0L,
                                name = name,
                                type = finalType,
                                currency = selectedCurrency,
                                initialBalance = finalInitialBalance,
                                iconName = selectedIcon,
                                isLiability = isLiability,

                                category = category,
                                creditLimit = if (category == "CREDIT") max(limitVal, 0.0) else 0.0,
                                debtType = finalDebtType
                            )

                            if (accountId == null) {
                                viewModel.insertAccount(toSave.copy(id = 0L))
                            } else {
                                viewModel.updateAccount(toSave)
                            }

                            navController.popBackStack()
                        },
                        enabled = accountName.isNotBlank()
                    ) {
                        Icon(Icons.Default.Check, contentDescription = stringResource(R.string.save), tint = primaryColor)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = bgColor)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 预览卡片
            AccountPreviewCard(
                name = if (accountName.isBlank()) stringResource(R.string.account_name_placeholder) else accountName,
                balance = amountInput,
                currency = selectedCurrency,
                iconName = selectedIcon,
                typeKey = selectedTypeKey,
                primaryColor = primaryColor,
                overrideTypeText = categoryBadgeText(category, debtType),
                overrideBalanceLabel = previewLabel
            )

            // 表单区域
            Card(
                colors = CardDefaults.cardColors(containerColor = surfaceColor),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    // 名称
                    OutlinedTextField(
                        value = accountName,
                        onValueChange = { accountName = it },
                        label = { Text(stringResource(R.string.account_name)) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(Modifier.height(16.dp))

                    // ✅ 类别（只显示，不允许在这里切换；入口由 AssetsScreen 的弹窗决定）
                    CategoryRow(category = category, debtType = debtType)

                    Spacer(Modifier.height(12.dp))

                    // FUNDS/CREDIT：显示账户类型；DEBT：显示债务方向（允许微调）
                    if (category != "DEBT") {
                        AccountTypeDropdown(
                            label = stringResource(R.string.account_type),
                            options = accountTypes,
                            selectedKey = selectedTypeKey,
                            onOptionSelected = { selectedTypeKey = it }
                        )
                        Spacer(Modifier.height(16.dp))
                    } else {
                        DebtTypeSelector(
                            debtType = debtType,
                            onChange = { debtType = it }
                        )
                        Spacer(Modifier.height(16.dp))
                    }

                    // 币种
                    DropdownInput(
                        label = stringResource(R.string.currency),
                        options = currencies,
                        selectedOption = selectedCurrency,
                        onOptionSelected = { selectedCurrency = it }
                    )

                    Spacer(Modifier.height(16.dp))

                    // 金额输入：FUNDS=余额，CREDIT=欠款，DEBT=未结清
                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = {
                            Text(
                                when (category) {
                                    "CREDIT" -> "欠款"
                                    "DEBT" -> "未结清金额"
                                    else -> stringResource(R.string.current_balance)
                                }
                            )
                        },
                        placeholder = { Text(stringResource(R.string.balance_placeholder)) },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // CREDIT：额度
                    if (category == "CREDIT") {
                        Spacer(Modifier.height(16.dp))
                        OutlinedTextField(
                            value = creditLimitInput,
                            onValueChange = { creditLimitInput = it },
                            label = { Text("额度") },
                            placeholder = { Text("例如：20000") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }

            // 图标选择器
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = stringResource(R.string.select_icon),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 8.dp, bottom = 12.dp)
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = surfaceColor),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 60.dp),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.heightIn(max = 300.dp)
                    ) {
                        items(icons) { (name, icon) ->
                            IconSelectionItem(
                                icon = icon,
                                isSelected = name == selectedIcon,
                                primaryColor = primaryColor,
                                onClick = { selectedIcon = name }
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

// ===== 小组件：类别显示 =====
@Composable
private fun CategoryRow(category: String, debtType: String?) {
    val text = categoryBadgeText(category, debtType)
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("账户类别", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(12.dp))
        AssistChip(
            onClick = { /* 不可切换 */ },
            label = { Text(text) }
        )
    }
}

private fun categoryBadgeText(category: String, debtType: String?): String {
    return when (category) {
        "CREDIT" -> "信贷账户"
        "DEBT" -> if ((debtType ?: "PAYABLE") == "RECEIVABLE") "借出（应收）" else "借入（应付）"
        else -> "资金账户"
    }
}

@Composable
private fun DebtTypeSelector(
    debtType: String?,
    onChange: (String) -> Unit
) {
    val current = debtType ?: "PAYABLE"
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("债务类型", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilterChip(
                selected = current == "PAYABLE",
                onClick = { onChange("PAYABLE") },
                label = { Text("借入（应付）") }
            )
            FilterChip(
                selected = current == "RECEIVABLE",
                onClick = { onChange("RECEIVABLE") },
                label = { Text("借出（应收）") }
            )
        }
    }
}

// ===== 预览卡片（可覆盖类型/余额标签）=====
@Composable
fun AccountPreviewCard(
    name: String,
    balance: String,
    currency: String,
    iconName: String?,
    typeKey: String,
    primaryColor: Color,
    overrideTypeText: String? = null,
    overrideBalanceLabel: String? = null
) {
    val displayBalance = if (balance.isBlank()) "0.00" else balance
    val typeName = overrideTypeText ?: AccountTypeManager.getDisplayName(typeKey)

    val brush = Brush.verticalGradient(
        colors = listOf(primaryColor.copy(alpha = 0.8f), primaryColor)
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .shadow(8.dp, RoundedCornerShape(24.dp), spotColor = primaryColor.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(brush)
        ) {
            Box(
                modifier = Modifier
                    .offset(x = 200.dp, y = (-50).dp)
                    .size(200.dp)
                    .background(Color.White.copy(alpha = 0.1f), CircleShape)
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color.White.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        val icon = iconName?.let { IconMapper.getIcon(it) } ?: Icons.Default.AccountBalanceWallet
                        Icon(imageVector = icon, contentDescription = null, tint = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = typeName,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                }

                Column {
                    Text(
                        text = overrideBalanceLabel ?: stringResource(R.string.current_balance),
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Spacer(Modifier.height(4.dp))

                    val balanceValue = remember(displayBalance) {
                        displayBalance.trim().replace(",", "").toDoubleOrNull() ?: 0.0
                    }

                    Text(
                        text = stringResource(R.string.currency_amount_format, currency, balanceValue),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

// --- 图标选择项 ---
@Composable
fun IconSelectionItem(
    icon: ImageVector,
    isSelected: Boolean,
    primaryColor: Color,
    onClick: () -> Unit
) {
    val bgColor by animateColorAsState(
        if (isSelected) primaryColor.copy(alpha = 0.1f) else Color.Transparent,
        label = "bgColor"
    )
    val iconColor by animateColorAsState(
        if (isSelected) primaryColor else MaterialTheme.colorScheme.onSurfaceVariant,
        label = "iconColor"
    )
    val border = if (isSelected) 2.dp else 0.dp

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(16.dp))
            .background(bgColor)
            .border(border, if (isSelected) primaryColor else Color.Transparent, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconColor,
            modifier = Modifier.size(28.dp)
        )
    }
}

// --- 通用下拉选择框 ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DropdownInput(
    label: String,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = Modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = selectedOption,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = {
                Icon(
                    Icons.Default.ArrowDropDown,
                    null,
                    modifier = Modifier.rotate(if (expanded) 180f else 0f)
                )
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent
            )
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(MaterialTheme.colorScheme.surface)
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onOptionSelected(option)
                        expanded = false
                    },
                    contentPadding = PaddingValues(horizontal = 16.dp)
                )
            }
        }
    }
}

// --- 账户类型专用下拉框 (支持多语言) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountTypeDropdown(
    label: String,
    options: List<Pair<String, Int>>, // Key, ResId
    selectedKey: String,
    onOptionSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    val selectedResId = AccountTypeManager.getTypeResId(selectedKey)
    val displayText = if (selectedResId != null) stringResource(selectedResId) else selectedKey

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = Modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = displayText,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = {
                Icon(
                    Icons.Default.ArrowDropDown,
                    null,
                    modifier = Modifier.rotate(if (expanded) 180f else 0f)
                )
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent
            )
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(MaterialTheme.colorScheme.surface)
        ) {
            options.forEach { (key, resId) ->
                DropdownMenuItem(
                    text = { Text(stringResource(resId)) },
                    onClick = {
                        onOptionSelected(key)
                        expanded = false
                    },
                    contentPadding = PaddingValues(horizontal = 16.dp)
                )
            }
        }
    }
}

fun Modifier.rotate(degrees: Float) = this.then(
    Modifier.graphicsLayer(rotationZ = degrees)
)

private fun formatNumberForInput(v: Double): String {
    return when {
        v == 0.0 -> ""
        v % 1.0 == 0.0 -> v.toLong().toString()
        else -> String.format(Locale.US, "%.2f", v)
    }
}

package com.swiftiecx.timeledger.ui.viewmodel.model

enum class ExpenseTypeFilter { ALL, EXPENSE, INCOME, TRANSFER }

package com.swiftiecx.timeledger.ui.viewmodel

/**
 * 兼容层：旧代码路径 com.swiftiecx.timeledger.ui.viewmodel.CategoryType
 */
typealias CategoryType = com.swiftiecx.timeledger.ui.viewmodel.model.CategoryType
